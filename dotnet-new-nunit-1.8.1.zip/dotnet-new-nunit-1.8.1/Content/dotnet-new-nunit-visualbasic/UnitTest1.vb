Imports NUnit.Framework

Namespace Company.TestProject1

    Public Class Tests

        <SetUp>
        Public Sub Setup()
        End Sub

        <Test>
        Public Sub Test1()
            Assert.Pass()
        End Sub

    End Class

End Namespace