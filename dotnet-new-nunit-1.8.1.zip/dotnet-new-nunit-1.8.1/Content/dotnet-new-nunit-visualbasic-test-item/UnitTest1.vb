Imports NUnit.Framework

Namespace Tests

    Public Class UnitTest1

        <SetUp>
        Public Sub Setup()
        End Sub

        <Test>
        Public Sub Test1()
            Assert.Pass()
        End Sub

    End Class

End Namespace